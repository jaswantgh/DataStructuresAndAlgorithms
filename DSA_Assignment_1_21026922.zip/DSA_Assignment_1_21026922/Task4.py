from LinkedList import LinkedList, Node
from hashtable import HashTable
import numpy as np

print('#' * 20, "Starting Task 4... Gathering data", '#' * 20)
def check_value(value, min_val, max_val):
    if min_val <= value <= max_val:
        return str(value)
    else:
        return str(value) + "(Caution: Out of Bounds)"

hash_table = HashTable(10)

with open('UAVdata.txt', 'r') as f:
    for line in f:
        data = np.array(line.strip().split())
        if len(data) != 4:
            print("Invalid data format:", line)
            continue
        try:
            uav_id = data[0]
            uav_data = (float(data[1]), float(data[2]), float(data[3]))
            hash_table.put(uav_id, uav_data)
        except ValueError:
            print("Invalid data values:", line)

valid_choice = False
while not valid_choice:
    uav_id = input("Choose a location from A to J: ")
    if uav_id in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']:
        valid_choice = True
    else:
        print("Invalid choice. Please choose a location from A to J.")

try:
    uav_data = hash_table.get(uav_id)
    print("Data for location {}: ".format(uav_id))
    print("Temperature: ", check_value(uav_data[0], 25, 48), "°C")
    print("Humidity: ", check_value(uav_data[1], 15, 60), "%")
    print("Wind Speed: ", check_value(uav_data[2], 30, 100), "km/h")
except TypeError as e:
    print("No data found for location {}".format(uav_id))
print('#' * 20, "End of Task 4", '#' * 20)
