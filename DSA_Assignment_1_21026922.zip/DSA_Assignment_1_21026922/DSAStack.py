from LinkedList import LinkedList, Node
#LIFO Principle used
class DSAStack:
    def __init__(self):
        self.items = LinkedList() #Initialise the stack using linkedlist

    def is_empty(self):
        return self.items.is_empty()  #Check if stack is empty

    def push(self, item):
        self.items.add(item)  #Add item to stack

    def pop(self):
        if self.is_empty(): #Handle when stack is empty
            var = None
        else:
            var = self.items.remove_first() #Remove and return top item from stack
        return var

    def size(self):
        return self.items.size() #Return size of stack

