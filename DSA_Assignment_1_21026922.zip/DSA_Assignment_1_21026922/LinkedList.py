class Node:
    def __init__(self, data=None, weight=None):
        self.data = data #initialize node's data
        self.weight = weight #initialize node's weight
        self.next = None # intialize pointer to next node

class LinkedList:
    def __init__(self):
        self.head = None #initialzie head of LL as none
        self.tail = None # initialize tail of LL as None
        self._length = 0 #initalize the lenght of LL as 0

    def add(self, data):
        new_node = Node(data) 
        if self.head is None: # check if LL is empty
            self.head = new_node # set new node as hd
            self.tail = new_node #set new node as tail
        else:
            self.tail.next = new_node #set new node as(pointed) next node for the current tail
            self.tail = new_node #update tail to the new node
        self._length += 1 # incrment the lenght of LL

    def add_last(self, data):
        if not self.head: 
            self.head = Node(data) # Create new node and set it as  head
        else:
            current = self.head
            while current.next: #traverse to last node
                current = current.next
            current.next = Node(data) # add new node ot the end of the LL

    def get(self, index):
        if index < 0: #check if the index is negative if not exception is raised below
            raise IndexError("Index cannot be negative.")
        curr = self.head 
        i = 0
        while curr is not None and i < index: #Traverse to the desired index 
            curr = curr.next
            i += 1
        if curr is None: #check if index is out of range
            raise IndexError("Index out of range.")
        return curr.data # reutrns data atdesired index

    def size(self):
        return self._length #return the length of LL

    def remove(self, data):
        if self.head is None: #check if LL is empty
            return

        if self.head.data == data: #check if head node contain data
            self.head = self.head.next #update head to next node
        else:
            current = self.head
            while current.next and current.next.data != data: #traverse node before node to be removed
                current = current.next

            if current.next and current.next.data == data: #check if node to be removed is found 
                current.next = current.next.next 


    def remove_first(self):
        removed_data = None

        if self.head is not None: 
            removed_data = self.head.data #get the data from head node
            self.head = self.head.next #update the head to the next node

        return removed_data 

    def contains(self, data):
        current = self.head
        found = False

        while current is not None and not found: #Traverse LL until data is found 
            if current.data == data:
                found = True
            else:
                current = current.next

        return found #Return wheter data is found or not

    def get_first(self):
        return self.head.data if self.head else None #Return  data of the head node if  exists

    def get_last(self):
        current = self.head
        while current and current.next: #Traverse to last node
            current = current.next
        return current.data if current else None # Return data of the last node if  exists

    def is_empty(self):
        return self.head is None #Check if the LL is empty by checking if the head is None

    def copy(self, other):
        current = other.head
        while current: #Traverse the other LL
            self.add_last(current.data) #Add each node's data to the current LL
            current = current.next

    def __iter__(self):
        node = self.head 
        while node is not None: #iterate/loop over the LL nodes
            yield node.data #yeild the data of the current node 
            node = node.next
            
    def print_list(self):
        node = self.head
        if node is not None: # check if LL is not empty
            print(node.data, end='') # print data of the head node
            node = node.next
        while node is not None: #traverse the LL and print data of each node
            print(' -> ', node.data, end=" ")
            node = node.next
        print() #printnew line at the end

    def get_length(self):
        return self._length #return length of the LL

    def get_head(self):
        return self.head #return  head node

    def set_head(self, node):
        self.head = node # set head node to the given node
