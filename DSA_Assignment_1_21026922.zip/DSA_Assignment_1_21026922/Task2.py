import numpy as np
from hashtable import HashTable
from Graph import GraphHT

print('#' * 20, "Starting Task 2... Gathering data", '#' * 20)
class WeatherData:
    def __init__(self, vertex, temperature, humidity, wind_speed):
        self.vertex = vertex
        self.temperature = temperature
        self.humidity = humidity
        self.wind_speed = wind_speed

    def display(self):
        print("Weather data for " + self.vertex + ":")
        print("Temperature: " + str(self.temperature) + "°C")
        print("Humidity: " + str(self.humidity) + "%")
        print("Wind speed: " + str(self.wind_speed) + "km/h")

try:
    with open("location.txt", "r") as f:
        line = f.readline()
        num_vertices, num_edges = map(int, np.array(line.strip().split()))
        g = GraphHT(num_vertices)
        line = f.readline()
        while line:
            line = line.strip()
            if line:  # Skip empty lines
                vertices = np.array(line.strip().split())
                v1, v2, weight = ord(vertices[0][0]) - ord('A'), ord(vertices[1][0]) - ord('A'), float(vertices[2])
                g.add_edge(v1, v2, weight)
            else:
                print("Empty line found:", line)  # Print empty lines for debug
            line = f.readline()

    hash_size = num_vertices * 2

    weather_data = HashTable(hash_size)

    with open("UAVdata.txt", "r") as f:
        line = f.readline()
        while line:
            vertex, temperature, humidity, wind_speed = np.array(line.strip().split())
            weather_data.put(vertex, WeatherData(vertex, float(temperature), float(humidity), float(wind_speed)))
            line = f.readline()

    # Prompt user for origin and destination vertices
    print("Please enter two locations to find the shortest distance(A-J):")
    origin_vertex = input("Enter Origin Vertex: ")
    destination_vertex = input("Enter Destination Vertex: ")
#converting vertex to numeric indicies
    origin_vertex_index = ord(origin_vertex) - ord('A')
    destination_vertex_index = ord(destination_vertex) - ord('A')

    shortest_path = g.bfs(origin_vertex_index, destination_vertex_index)

    if shortest_path:
        # Convert numeric indices back to vertex labels
        shortest_path_str = ""
        path_node = shortest_path.get_head()
        while path_node is not None:
            shortest_path_str += chr(path_node.data.data + ord('A')) + " -> "
            path_node = path_node.next

        # Display shortest path
        print("BFS Traversal:")
        print(shortest_path_str[:-4])

        # Display weather data for origin and destination vertices
        origin_weather = weather_data.get(origin_vertex)
        destination_weather = weather_data.get(destination_vertex)
        print()
        origin_weather.display()
        print()
        destination_weather.display()

        # Perform DFS traversal
        print("\nDFS Traversal:")
        g.dfs(origin_vertex_index)
    else:
        print("There is no path from", origin_vertex, "to", destination_vertex + ".")
except FileNotFoundError:
    print("File not found. Please make sure the input files (location.txt and UAVdata.txt) exist.")
except Exception as e:
    print("An error occurred:", str(e))

