from hashtable import HashTable
from LinkedList import LinkedList
from Heap import Heap
import numpy as np

print('#' * 20, "Starting Task 6... Gathering data", '#' * 20)

class Area:
    def __init__(self, name, x, y, z):
        self.name = name 
        self.x = x 
        self.y = y 
        self.z = z #coordiantes intialized
        self.risk = x + y + z #calculate risk by summing the coordinates

    def __lt__(self, other):
        return self.risk < other.risk #risk of two area objects are compared

    def __gt__(self, other):
        return self.risk > other.risk #risk of two area objects are compared
    
    def __str__(self):
        return f"Area Name: {self.name}, Coordinates: ({self.x}, {self.y}, {self.z})" 

class UAV:
    def __init__(self):
        self.data = LinkedList() #Initialzie a LL to store data
        self.locations = HashTable(100) #initalize ht to store locations
        self.risk_values = HashTable(100) #initalize ht to store risk values

    def load_data(self, filename):
        with open(filename, "r") as f:
            lines = f.readlines()
            for line in lines:
                parts = np.array(line.strip().split()) #split line into parts
                name = parts[0]
                x = float(parts[1])
                y = float(parts[2])
                z = float(parts[3])
                area = Area(name, x, y, z) #create area object
                self.data.add(area) #add area to the data LL
                self.locations.put(name, (x, y, z)) #store location int eh locations ht
                self.risk_values.put(name, x + y + z) #store risk value

    def distance(self, a, b):
        ax, ay, az = self.locations.get(a) 
        bx, by, bz = self.locations.get(b) #get coordinates
        return ((ax - bx) ** 2 + (ay - by) ** 2 + (az - bz) ** 2) ** 0.5 #calculate the euclidean distance in 3 dimensional space
    
    def save_data(self, filename):
        with open(filename, "w") as f:
            for area in self.data:
                f.write(f"{area.name} {area.x} {area.y} {area.z}\n") #write area info to file

    def show_itinerary(self, start):
        print(f"If {start} is selected:")
        heap = Heap() #create heap ds to store itinarey 
        visited = LinkedList() # create LL to track visited areas
        path = LinkedList() # create LL to store current path
        path.add(start) #add start area to path
        candidates_not_empty = True 
        while candidates_not_empty:
            current = path.get_last() 
            visited.add(current)  
            candidates = LinkedList() 
            for area in self.data: #iterate through all areas using loop
                if area.name not in visited and area.risk > 120: #check if area not visted has a risk greater than 120 - 120 because using eucildean formula this is reasonable number for values to be in a particualr range
                    candidates.add(area) #add area to candidates list
            candidates_not_empty = not candidates.is_empty() 
            if candidates_not_empty:
                min_distance = float("inf") #init min distance as infinity
                next_area = None #variable to store the next area with min distance
                for candidate in candidates: #iterate loop
                    dist = self.distance(current, candidate.name) #calculate distance from current area to the candidate area
                    if dist < min_distance: #check if distance is smaller than the min distance
                        min_distance = dist # updte
                        next_area = candidate #updte the next area with min distance
                if next_area:
                    path.add(next_area.name) #add next area topath
        path.print_list() 

    def show_summary(self):
        for start in self.data: #iterate loop through all the areas in  data
            if start.risk > 0: #check if the starting area has non-zero risk
                print(f"From {start.name}:") 
                for end in self.data: #iterat loop
                    if start.name != end.name and end.risk > 0: #check if starting area is not the same as ending area 
                        print(f"  - To {end.name}: {self.distance(start.name, end.name):.2f}")

class FileNotFoundError(Exception):
    pass

class AreaNotFoundError(Exception):
    pass


uav = UAV()
try:
    uav.load_data("UAVdata.txt")
except FileNotFoundError:
    print("Error: File 'UAVdata.txt' not found. Please ensure the file exists.")
choice = ""
while choice != "3":
    print("\nSelect an option:")
    print("(1) Show Itinerary Path for a Location")
    print("(2) Show Summary of All Path Distances")
    print("(3) Exit")
    try:
        choice = input("Enter your choice: ")
    except EOFError:
        print("Error: Unexpected end of input. Please try again.")
        continue

    if choice == "1":
        start = input("Enter starting area: ")
        try:
            uav.show_itinerary(start)
        except AreaNotFoundError:
            print(f"Error: Area {start} not found. Please try again.")
    elif choice == "2":
        uav.show_summary()
    elif choice != "3":
        print("Error: Invalid choice. Please try again.")

print('#' * 20, "End of Task 6", '#' * 20)
