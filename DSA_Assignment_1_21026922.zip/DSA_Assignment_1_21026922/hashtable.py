import numpy as np

class HashNode:
    def __init__(self, key=None, value=None, next=None):
        self.key = key #initialize key of node
        self.value = value # intialize value of node
        self.next = next # intialize thenext pointer of the node

class HashTable:
    def __init__(self, size):
        self.size = size #store size of ht
        self.table = np.empty(size, dtype=object)  # Use np to create a ht

    def hash(self, key):
        return hash(key) % self.size #hash value of key

    def put(self, key, value):
        index = self.hash(key) #index for ht for the key
        node = self.table[index] # get node at the particular index 
        if node is None: 
            self.table[index] = HashNode(key, value)
        else:
            while node.next is not None: # traverse to the last node in the LL
                node = node.next
            node.next = HashNode(key, value) # create new node -> append it to LL

    def get(self, key):
        index = self.hash(key) 
        node = self.table[index] 
        value = None

        while node is not None and value is None: #traverse the LL until the key is reached
            if node.key == key: #key matches node's key, assign value to variable
                value = node.value
            node = node.next

        return value #return value associated with the key

    def contains(self, key): 
        index = self.hash(key) 
        node = self.table[index] # get node at the calcualtedindex
        found = False

        while node is not None and not found: #traverse the LL until key found
            if node.key == key: #key match then true
                found = True
            node = node.next

        return found #return true if  key  found


    def items(self):
        for i in range(self.size): #iterate/loop over ht array
            node = self.table[i] #get the ndoe at the current index
            while node is not None: #traverse the LL
                yield node.key, node.value # yield the key value pair
                node = node.next # move the enxt node in the LL
