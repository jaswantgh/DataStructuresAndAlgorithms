# Importing Libraries
from Graph import NeighborNode, Vertex, GraphLL
import numpy as np

# Utility Functions
def creating_adjacency_graph():
    '''Will create the adjacency list by reading the data'''
    graph = GraphLL()
    with open("location.txt", "r") as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            if line:
                data = np.array(line.split())
                if len(data) == 3:
                    frm, to, weight = data
                    graph.add_edge(frm, to, float(weight))
    print("Adjacency List Building........")
    graph.print_adjacency_list()

def read_location_file():
    '''Will read the file'''
    print("\nReading location.txt")
    with open('location.txt', 'r') as file:
        lines = file.readlines()
        for line in lines:
            line = line.strip()
            print(line)
# Flag  
exit_menu = False
# Heading
print('#' * 20, "Starting Task 1... Gathering data", '#' * 20)
# Main Menu
print("\nInteractive Menu")
print("1. Location.txt File")
print("2. Adjacancey List as Graph")
print("3. Exit")
while not exit_menu:
    try:
        choice = int(input("Enter your choice: "))
        if choice == 1:
            read_location_file()
        elif choice == 2:
            creating_adjacency_graph()
        elif choice == 3:
            print("Exiting...")
            exit_menu = True
        else:
            print("Invalid choice!")
    except ValueError:
        print("Invalid input, please enter a number.")

# Termination
print('#' * 20, "End of Task 1", '#' * 20)
