from Graph import *
from DSAQueue import *
from DSAStack import *
from hashtable import *
from Heap import *
from LinkedList import *

class Area:
    def __init__(self, name, x, y, z):
        self.name = name
        self.x = x
        self.y = y
        self.z = z
        self.risk = x + y + z

    def __lt__(self, other):
        return self.risk < other.risk

    def __gt__(self, other):
        return self.risk > other.risk
    
    def __str__(self):
        return f"Area Name: {self.name}, Coordinates: ({self.x}, {self.y}, {self.z})"
    
def menu():
    print("\nInteractive Menu")
    print("1. Task")
    print("2. Data Structure")
    print("3. Read location.txt")
    print("4. Read UAVdata.txt")
    print("5. Exit")

def task():
    print("\nTask")
    print("1. Task1.py")
    print("2. Task2.py")
    print("3. Task3.py")
    print("4. Task4.py")
    print("5. Task5.py")
    print("6. Task6.py")
    print("7. UnitTestX.py")
    print("8. Back to main menu")

    choice = int(input("Enter your choice: "))
    if 1 <= choice <= 7:
        module_name = f"Task{choice}.py"
        exec(open(module_name).read())
    elif choice == 8:
        return
    else:
        print("Invalid choice!")

def data_structure():
    print("\nData Structure")
    print("1. Graph.py")
    print("2. hashtable.py")
    print("3. Heap.py")
    print("4. LinkedList.py")
    print("5. DSAStack.py")
    print("6. DSAQueue.py")
    print("7. Back to main menu")

    choice = int(input("Enter your choice: "))
    if 1 <= choice <= 6:
        module_name = np.array(["Graph.py", "hashtable.py", "Heap.py", "LinkedList.py", "DSAStack.py", "DSAQueue.py"])[choice-1]
        exec(open(module_name).read())
    elif choice == 7:
        return
    else:
        print("Invalid choice!")

def read_location_file():
    print("\nReading location.txt")
    with open('location.txt', 'r') as file:
        lines = file.readlines()
        for line in lines:
            line = line.strip()
            print(line)

def read_UAVdata_file():
    print("\nReading UAVdata.txt")
    with open('UAVdata.txt', 'r') as file:
        lines = file.readlines()
        for line in lines:
            line = line.strip()
            print(line)

is_running = True
while is_running:
    try:
        menu()
        choice = int(input("Enter your choice: "))
        if choice == 1:
            task()
        elif choice == 2:
            data_structure()
        elif choice == 3:
            read_location_file()
        elif choice == 4:
            read_UAVdata_file()
        elif choice == 5:
            print("Exiting...")
            is_running = False
        else:
            print("Invalid choice!")
    except ValueError:
        print("Invalid input, please enter a number.")

