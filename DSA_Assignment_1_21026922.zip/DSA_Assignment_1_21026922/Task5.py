from hashtable import HashTable
from Heap import Heap
from LinkedList import LinkedList
print('#' * 20, "Starting Task 5... Gathering data", '#' * 20)
def risk_level_temp(temp):
    if temp > 40:
        var = 3  # High risk
    elif 33 <= temp <= 40:
        var = 2  # Medium risk
    else:
        var = 1  # Low risk
    return var

def risk_level_humidity(humidity):
    if humidity < 30:
        var = 3   # High risk
    elif 31 <= humidity <= 50:
        var = 2   # Medium risk
    else:
        var = 1   # Low risk
    return var

def risk_level_wind(wind):
    if wind > 55:
        var = 3  # High risk
    elif 41 <= wind <= 55:
        var = 2 # Medium risk
    else:
        var = 1 # Low risk
    return var

def risk_description(risk):
    if risk == 3:
        var = 'high risk'
    elif risk == 2:
        var = 'medium risk'
    else:
        var = 'low risk'
    return var
def calculate_overall_risk(risks):
    total_risk = sum(risks)
    total_count = len(risks)
    return total_risk / total_count

def risk_level_description(overall_risk):
    if overall_risk < 1:
        var = "very low"
    elif 1 <= overall_risk < 2:
        var = "low to medium"
    elif 2 <= overall_risk < 3:
        var =  "medium to high"
    else:
        var = "very high"
    return var

def split_str(string):
    first_space_index = string.find(' ') #first space index (1)
    area = string[:first_space_index] #extract name from  string

    remaining_string = string[first_space_index + 1:] #extract  remainig string after (1) 
    second_space_index = remaining_string.find(' ') # find index of second spcae in remanig
    temp = float(remaining_string[:second_space_index]) #extract temperature value as float

    remaining_string = remaining_string[second_space_index + 1:] #extract remaining string after 2nd space
    third_space_index = remaining_string.find(' ') #  thrid space in the remaining string
    humidity = float(remaining_string[:third_space_index]) #extract humidity value as float

    wind = float(remaining_string[third_space_index + 1:]) # extract wind value as float

    return area, temp, humidity, wind 

def calculate_max_risk(risk_temp, risk_humidity, risk_wind):
    max_risk = risk_temp   # caclulate max risk
    if risk_humidity > max_risk:
        max_risk = risk_humidity
    if risk_wind > max_risk:
        max_risk = risk_wind

    return max_risk

data = LinkedList() # create LL to store 
risk_table = HashTable(50) #create ht to store risk values
heap = Heap() # creat hp to store 

with open('UAVdata.txt', 'r') as file:
    for line in file:
        area, temp, humidity, wind = split_str(line) #split line into area, temp, humidity and wind values

        risk_temp = risk_level_temp(temp) #calculate risk level for temp
        risk_humidity = risk_level_humidity(humidity) # calculate risk level for humidity 
        risk_wind = risk_level_wind(wind) # calculate risk level for wind
#store risk values in risk table
        risk_table.put(area, (temp, risk_temp, humidity, risk_humidity, wind, risk_wind)) #calculate max risk among the risk values
        heap.push((area, calculate_max_risk(risk_temp, risk_humidity, risk_wind))) #push0 area and its max risk into  heap
        data.add((area, temp, risk_temp, humidity, risk_humidity, wind, risk_wind)) #add data to the LL

exit = False
while not exit:
    print("\n\nMenu:")
    print("1. Check Temperature and Risk Factor(A-J)")
    print("2. Check Humidity and Risk Factor(A-J)")
    print("3. Check Wind Speed and Risk Factor(A-J)")
    print("4. Check Total Risk Factor(A-J)")
    print("5. Check Temperature, Humidity, Wind Speed and Risk Factor of an Area(A-J)")
    print("6. Conclusion of the Highest Risk and Lowest Risk Areas with Reasoning")
    print("7. Exit")
    choice = input("Enter your choice: ")

    if choice == '1':
        area = input("Enter area: ")
        area_data = risk_table.get(area)
        if area_data is None:
            print("Area not found.")
        else:
            temp, risk_temp = area_data[0], area_data[1]
            print(f"Temperature: {temp}, Risk Factor: {risk_temp} ({risk_description(risk_temp)})")

    elif choice == '2':
        area = input("Enter area: ")
        area_data = risk_table.get(area)
        if area_data is None:
            print("Area not found.")
        else:
            humidity, risk_humidity = area_data[2], area_data[3]
            print(f"Humidity: {humidity}, Risk Factor: {risk_humidity} ({risk_description(risk_humidity)})")

    elif choice == '3':
        area = input("Enter area: ")
        area_data = risk_table.get(area)
        if area_data is None:
            print("Area not found.")
        else:
            wind, risk_wind = area_data[4], area_data[5]
            print(f"Wind Speed: {wind}, Risk Factor: {risk_wind} ({risk_description(risk_wind)})")

    elif choice == '4':
        area = input("Enter area: ")
        area_data = risk_table.get(area)
        if area_data is None:
            print("Area not found.")
        else:
            risks = [area_data[1], area_data[3], area_data[5]]  
            overall_risk = calculate_overall_risk(risks)
            risk_description = risk_level_description(overall_risk)
            print(f"Overall Risk Factor: {overall_risk}. The overall risk is {risk_description}.")
    elif choice == '5':
        area = input("Enter area: ")
        area_data = risk_table.get(area)
        if area_data is None:
            print("Area not found.")
        else:
            temp, risk_temp, humidity, risk_humidity, wind, risk_wind = area_data
            print(f"Temperature: {temp}, Risk Factor: {risk_temp} ({risk_description(risk_temp)})")
            print(f"Humidity: {humidity}, Risk Factor: {risk_humidity} ({risk_description(risk_humidity)})")
            print(f"Wind Speed: {wind}, Risk Factor: {risk_wind} ({risk_description(risk_wind)})")
        
        
    elif choice == '6':
        highest_risk_area = None
        highest_risk_value = None
        lowest_risk_area = None
        lowest_risk_value = None
        for area, area_data in risk_table.items():
            risk_temp, risk_humidity, risk_wind = area_data[1], area_data[3], area_data[5]
            overall_risk = (risk_temp + risk_humidity + risk_wind) / 3
            if highest_risk_value is None or overall_risk > highest_risk_value:
                highest_risk_area = area
                highest_risk_value = overall_risk
            if lowest_risk_value is None or overall_risk < lowest_risk_value:
                lowest_risk_area = area
                lowest_risk_value = overall_risk
        print(f"Highest Risk Area: {highest_risk_area}, Risk Factor: {highest_risk_value} ({risk_level_description(highest_risk_value)})")
        print(f"Lowest Risk Area: {lowest_risk_area}, Risk Factor: {lowest_risk_value} ({risk_level_description(lowest_risk_value)})")
    
    elif choice == '7':
        exit = True
    else:
        print("Invalid choice. Please enter a number from 1 to 7.")
print('#' * 20, "End of Task 5", '#' * 20)
