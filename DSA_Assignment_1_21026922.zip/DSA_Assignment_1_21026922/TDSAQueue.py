from DSAQueue import DSAQueue

def test_queue_methods():
    print("\n#########################################\n\tTESTING QUEUE\n#########################################\n")

    # Start off with an empty queue
    q = DSAQueue()
    print("Initial Queue:")
    q.items.print_list()
    print("Queue is empty:", q.is_empty())
    print("Queue size:", q.size())

    # Test enqueue method
    print("\n> Enqueue method test")
    for i in range(1, 6):
        q.enqueue(i)
    print("Queue after enqueue:")
    q.items.print_list()
    print("Queue is empty:", q.is_empty())
    print("Queue size:", q.size())

    # Test dequeue method
    print("\n> Dequeue method test")
    while not q.is_empty():
        dequeued_item = q.dequeue()
        print("Dequeued item:", dequeued_item)
    print("Queue after dequeue:")
    q.items.print_list()
    print("Queue is empty:", q.is_empty())
    print("Queue size:", q.size())

    # Test exception handling for dequeue on empty queue
    print("\n> Exception handling for dequeue on empty queue")
    try:
        q.dequeue()
    except Exception as e:
        assert str(e) == "Queue is empty"
        print("Exception caught:", e)

    print("\n#########################################\n\tEND OF QUEUE TEST\n#########################################\n")


if __name__ == '__main__':
    test_queue_methods()

