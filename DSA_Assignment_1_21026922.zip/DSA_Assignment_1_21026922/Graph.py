from LinkedList import LinkedList, Node
from DSAQueue import DSAQueue
from DSAStack import DSAStack
from hashtable import HashTable

class NeighborNode:
    def __init__(self, vertex, weight):
        self.vertex = vertex 
        self.weight = weight  
        self.next = None # Pointer

class Vertex:
    def __init__(self, name):
        self.name = name #Sotres idenitifer
        self.neighbors = LinkedList() # Store list of NeighborNode
#Add neighbor to vertex
    def add_neighbor(self, vertex, weight):
        self.neighbors.add(NeighborNode(vertex, weight)) #Add NeihborNode to list of nbors
    def get_neighbors(self):
        neighbors = LinkedList()
        current_neighbor = self.neighbors.head
        while current_neighbor is not None:
            neighbors.add(current_neighbor.data.vertex) #Add each neigbr to the list
            current_neighbor = current_neighbor.next
        return neighbors
class GraphLL:
    def __init__(self): #constructor
        self.vertices = LinkedList() #Initialize verties as an instance of LL
#Add vertex to graph
    def add_vertex(self, vertex): #method to add v to graph
        self.vertices.add(vertex) #append vertex to v LL

    def add_edge(self, frm, to, weight): 
        frm_vertex = None #initialize
        to_vertex = None #initialize
        current_vertex = self.vertices.head #start from head of v LL

        while current_vertex is not None: #loop used to iterate/find that match from_vertex and to_vertex if exisist
            vertex = current_vertex.data
            if vertex.name == frm: #if name matches
                frm_vertex = vertex 
            if vertex.name == to: 
                to_vertex = vertex
            current_vertex = current_vertex.next

        if frm_vertex is None: #if frm vertex and tovertex D.N.E, create them n add to verticies list
            frm_vertex = Vertex(frm)
            self.vertices.add(frm_vertex)
        if to_vertex is None:
            to_vertex = Vertex(to)
            self.vertices.add(to_vertex)

        frm_vertex.add_neighbor(to_vertex, weight) #add vertex as a neigjbour to from_vertex with a given weight

    def print_adjacency_list(self):
        print("Number of vertices:", self.vertices.size()) #print total number of verticies
        num_edges = 0
        current_vertex = self.vertices.head
        while current_vertex is not None:
            vertex = current_vertex.data
            num_edges += vertex.neighbors.size() #increment the total of edges
            print(vertex.name, end=" -> ")
            neighbor_curr = vertex.neighbors.head
            while neighbor_curr is not None: #loop through each neighbor of the current vertex
                neighbor = neighbor_curr.data
                print(neighbor.vertex.name + "(" + str(neighbor.weight) + ")", end=" ") #print name of neighbor vertex and its weight
                neighbor_curr = neighbor_curr.next
            print() #print line break to move next line
            current_vertex = current_vertex.next
#move next vertex in LL
        print("Number of edges:", num_edges) #print total number of edges

    def insert_vertex(self, vertex_name):
        current_vertex = self.vertices.head #search for vertex in the graph
        while current_vertex is not None:
            if current_vertex.data.name == vertex_name:
                print(f"Vertex {vertex_name} already exists.")
                return
            current_vertex = current_vertex.next

        new_vertex = Vertex(vertex_name) #if vertex D.N.E , create a new vertex and add it to graph
        self.vertices.add(new_vertex)
        n = input("Enter number of edges: ") # for each new edge
        for _ in range(int(n)):# _ is a throwaway vairable
            to = input("Enter vertex End: ") 
            weight = input("Enter weight: ")
            self.add_edge(vertex_name, to, float(weight)) #add edge to graph using add_edge1

    def delete_vertex(self, vertex_name):
        current_vertex = self.vertices.head # set current vertx to head of LL
        prev_vertex = None 
        while current_vertex is not None: #iterate until current vertex become None
            if current_vertex.data.name == vertex_name: #if name matches
                # Remove vertex from its neighbors
                current_neighbor = current_vertex.data.neighbors.head #set current to hed of neighbor LL of current vertex
                while current_neighbor is not None: #iterates until c_neigbor is none
                    neighbor = current_neighbor.data.vertex 
                    neighbor_neighbors = neighbor.neighbors.head 
                    prev_neighbor = None 
                    removal_done = False 
                    while neighbor_neighbors is not None and not removal_done:#loop through neighbor
                        if neighbor_neighbors.data.vertex == current_vertex.data: #remove referene
                            if prev_neighbor is None: # n_n head of neighbor LL
                                neighbor.neighbors.head = neighbor_neighbors.next # remove head of neighbor LL
                            else:
                                prev_neighbor.next = neighbor_neighbors.next #remove n_n from neighbor LL
                            removal_done = True #removal has been done
                        else:
                            prev_neighbor = neighbor_neighbors # move prev_n to current n_n
                            neighbor_neighbors = neighbor_neighbors.next #move n_n to next n

                    current_neighbor = current_neighbor.next #move current_n to next neigbor of the current vertex

                # Remove vertex from the graph
                if prev_vertex is None: #current_vrtex is head of LL
                    self.vertices.head = current_vertex.next #remove head of LL
                else:
                    prev_vertex.next = current_vertex.next  #remove the current_vertex from LL

                print(f"Vertex {vertex_name} deleted.")
                return

            prev_vertex = current_vertex #move prev v to curent v
            current_vertex = current_vertex.next #move current v to next v

        print(f"Vertex {vertex_name} not found.")
#Searches for a vertex in the graph
    def search_vertex(self, vertex_name): 
        current_vertex = self.vertices.head #set current_vertex to head of LL

        while current_vertex is not None: #loop iterates until current_vertex become is None
            if current_vertex.data.name == vertex_name: #if name matches
                vertex = current_vertex.data #set v to data of current_vertex
                print(f"Neighbors of {vertex_name}:")
                current_neighbor = vertex.neighbors.head #set current neighbor to head of neighbor LL of v
                while current_neighbor is not None: #iterate loop
                    neighbor = current_neighbor.data.vertex #get neigbor vertex
                    weight = current_neighbor.data.weight #get weight of edge 
                    print(f"{neighbor.name}({weight:.1f})")
                    current_neighbor = current_neighbor.next 
                return 
            current_vertex = current_vertex.next 

        print(f"Vertex {vertex_name} not found.")

class GraphHT:
    def __init__(self, vertices):
        self.num_vertices = vertices #store no. of v in graph
        self.adj_list = HashTable(vertices) #hashtabl store the AL
#Add edge between two vertieces in the graph
    def add_edge(self, v1, v2, weight):
        if self.adj_list.contains(v1): #if v 1 exists in AL
            linked_list = self.adj_list.get(v1) # get the LL associated with v1
            linked_list.add_last(Node(v2, weight)) # add a new node to LL with v2 and weight
        else:
            linked_list = LinkedList() # create a new LL
            linked_list.add_last(Node(v2, weight)) #add a new node to the LL w v2 and weight
            self.adj_list.put(v1, linked_list) # add the LL to the adjaceny list

        if self.adj_list.contains(v2): # if v2 exists in AL
            linked_list = self.adj_list.get(v2) # get LL associated w V2
            linked_list.add_last(Node(v1, weight)) # add new node to LL w V1 and weight
        else:
            linked_list = LinkedList() #create new LL
            linked_list.add_last(Node(v1, weight)) # add new node to the LL w v1 and weight
            self.adj_list.put(v2, linked_list) #add the LL to AL
        print("Edge added: ", v1, v2) 
#Remove edge between two vertices in the graph
    def remove_edge(self, v1, v2): 
        if self.adj_list.contains(v1): #if v1 exists in AL 
            linked_list = self.adj_list.get(v1) #get LL associated with v1
            linked_list.remove(Node(v2)) #remove node v1 from LL

        if self.adj_list.contains(v2):
            linked_list = self.adj_list.get(v2)
            linked_list.remove(Node(v1))
#Check if edge exists between two verticies in the graph
    def get_edge(self, v1, v2):
        if self.adj_list.contains(v1):
            linked_list = self.adj_list.get(v1)
            return linked_list.contains(Node(v2)) #check if node with v2 is present in the LL
        return False #return false if v1 D.N.E in the AL

    def get_adjacent_vertices(self, v): 
        adjacent_vertices = LinkedList() #creatte new LL to store the AV 
        if self.adj_list.contains(v): #if vertex v exists in the adjacency list
            linked_list = self.adj_list.get(v) #get LL associated with v
            current = linked_list.get_head() # get head of LL
            while current: #iterate through LL
                adjacent_vertices.add_last(current.data) #Add adjacent vertex to the LL
                current = current.next 
        return adjacent_vertices #return LL 

    def bfs(self, start_vertex, destination_vertex):
        visited = HashTable(self.num_vertices) #creates hashtable to store visted verteices
        queue = DSAQueue() #queue for BFS traversal
        path = LinkedList() #create LL to store path
        path.add_last(Node(start_vertex)) # add start_vertex
        queue.enqueue(path) #enquueud
        visited.put(start_vertex, True) # mark 

        while not queue.is_empty(): #continuess until queue is empty
            current_path = queue.dequeue() #dequeue a path fro.m the queue
            current_vertex = current_path.get_last().data #Get the alst vertex in the current path
            print("Current vertex:", current_vertex) 

            if current_vertex == destination_vertex:
                return current_path

            adjacent_vertices = self.get_adjacent_vertices(current_vertex) 
            current = adjacent_vertices.get_head() 
            while current: 
                vertex = current.data.data 
                if not visited.contains(vertex): 
                    new_path = LinkedList() #create new path
                    new_path.copy(current_path) 
                    new_path.add_last(current.data) 
                    queue.enqueue(new_path) 
                    visited.put(vertex, True) 
                current = current.next # move to the next node

        return None 

    def dfs(self, start_vertex):
        visited = HashTable(self.num_vertices) #hashatable created to store visited verticies
        self.dfs_helper(start_vertex, visited) # call helper method for DFS traversal
#Helper method fro the DFS algo
    def dfs_helper(self, vertex, visited): 
        visited.put(vertex, True) 
        print("Visited vertex:", chr(vertex + ord('A')))

        adjacent_vertices = self.get_adjacent_vertices(vertex) 
        current = adjacent_vertices.get_head() 
        while current: # iterate through the adjacent verteices
            v = current.data.data 
            if not visited.contains(v): 
                self.dfs_helper(v, visited) # recursively call the helper method for the vertex
            current = current.next 
    

        


