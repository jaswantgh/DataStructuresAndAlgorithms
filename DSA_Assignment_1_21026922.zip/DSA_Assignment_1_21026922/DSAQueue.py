#Importing LinkedList file
from LinkedList import LinkedList, Node
#FIFO principle used
class DSAQueue:
    def __init__(self):
        self.items = LinkedList()    #Initialize queue using linked list

    def is_empty(self):
        return self.items.is_empty()  # Checking if queue is empty

    def enqueue(self, item):
        self.items.add(item)           # Add item to queue

    def dequeue(self):                    
        if self.is_empty():              # Handle when queue is empty
            var = None
        else:
            var = self.items.remove_first()  # Remove and return first item in the queue
        return var
        
    def size(self):
        return self.items.size()   #Return size of queue

