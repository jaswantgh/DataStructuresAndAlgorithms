from LinkedList import LinkedList, Node
from Graph import Vertex, GraphLL, NeighborNode
import numpy as np

print('#' * 20, "Starting Task 3... Gathering data", '#' * 20)
def build_graph(filename):
    graph = GraphLL()
    with open(filename) as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            if line:
                data = np.array(line.split())
                if len(data) == 3:
                    frm, to, weight = data
                    graph.add_edge(frm, to, float(weight))
    return graph

graph = build_graph('location.txt')
is_running = True
while is_running:
    print('\nMenu:')
    print('1. Print adjacency list')
    print('2. Insert vertex')
    print('3. Delete vertex')
    print('4. Search vertex')
    print('5. Exit')

    choice = input('Enter your choice: ')
    if choice == '1':
        graph.print_adjacency_list()
    elif choice == '2':
        vertex_name = input('Enter vertex name: ')
        graph.insert_vertex(vertex_name)
    elif choice == '3':
        vertex_name = input('Enter vertex name: ')
        graph.delete_vertex(vertex_name)
    elif choice == '4':
        vertex_name = input('Enter vertex name: ')
        graph.search_vertex(vertex_name)
    elif choice == '5':
        is_running = False
    else:
        print('Invalid choice')


print('#' * 20, "End of Task 3", '#' * 20)
