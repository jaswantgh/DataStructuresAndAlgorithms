from LinkedList import LinkedList, Node

class Heap:
    def __init__(self):
        self.heap = LinkedList() # heap as LL

    def push(self, item):
        self.heap.add(item) #add item to heap
        self._sift_up(self.heap.size() - 1) #perform sift-up 

    def pop(self):
        if self.heap.size() == 0: 
            raise IndexError("pop from empty heap") #exception raised if heap is empty
        item = self.heap.get(0) #get root item 
        last_item = self.heap.get(self.heap.size() - 1) #get last item in heap
        self.heap.remove(self.heap.size() - 1) #remove last item from  heap
        if self.heap.size() > 0: #if the heap is not empty after removing
            self.heap.add(item) #move root item to last position
            self._sift_down(0) #perform sift-down 
        return last_item 

    def _sift_up(self, i):
        parent = (i - 1) // 2 # parent index of given index
        while i > 0 and self.heap.get(parent) < self.heap.get(i):  # Changed comparison
            parent_val = self.heap.get(parent) #get parent value
            self.heap.remove(parent) #remove parent value
            self.heap.add(parent_val) # add the parent value back
            i = parent # update current index to the parent index
            parent = (i - 1) // 2 #  new parent index

    def _sift_down(self, i):
        child1 = 2 * i + 1 # index of the left child
        child2 = 2 * i + 2 # ht index of the right child
        while child1 < self.heap.size(): #  sift-down perfomred
            if child2 >= self.heap.size() or self.heap.get(child1) > self.heap.get(child2):  # Changed comparison to make max heap
                child = child1
            else:
                child = child2
            if self.heap.get(i) < self.heap.get(child):  # Changed comp make max hp
                child_val = self.heap.get(child) #get the child value
                self.heap.remove(child) # remove the child valu
                self.heap.add(child_val) # add the child back ( swap positions)
                i = child #current index to child index is update
                child1 = 2 * i + 1 # new left child index
                child2 = 2 * i + 2 #new right child index
            else:
                return 
